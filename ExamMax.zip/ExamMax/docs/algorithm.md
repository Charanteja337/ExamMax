# ExamMax Algorithm

## Problem
Select exam questions within a fixed time limit so that the total expected marks are maximized.

## DAA Modeling
This is modeled as the **0/1 Knapsack problem**.

| ExamMax concept | 0/1 Knapsack concept |
|---|---|
| Exam time | Capacity |
| Question | Item |
| Estimated answer time | Weight |
| Expected marks | Value |

Each question may be selected at most once.

## Dynamic Programming State
`dp[i][t]` = maximum expected marks obtainable using the first `i` questions with at most `t` minutes.

## Recurrence
If question `i` requires more than `t` minutes:

`dp[i][t] = dp[i-1][t]`

Otherwise:

`dp[i][t] = max(dp[i-1][t], dp[i-1][t-time[i]] + marks[i])`

## Complexity
- Time: **O(N × T)**
- Space: **O(N × T)** because this version stores the DP table to reconstruct the selected questions.
- If only the maximum score is required, the DP can be reduced to **O(T)** space.

## Important Edge Cases
- No question fits.
- One question exactly matches the available time.
- Multiple combinations give similar marks.
- Zero or invalid input should be rejected by the web API.
- Large exam time or many questions should be performance-tested.
