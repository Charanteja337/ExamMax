const questionsBox = document.getElementById("questions");
const addQuestionBtn = document.getElementById("addQuestion");
const optimizeBtn = document.getElementById("optimizeBtn");
const errorBox = document.getElementById("errorBox");
const resultCard = document.getElementById("resultCard");

let questionCount = 0;

function addQuestion(name = "", time = "", marks = "") {
    questionCount += 1;
    const row = document.createElement("div");
    row.className = "question-row";
    row.innerHTML = `
        <input class="input name" type="text" value="${name || `Q${questionCount}`}" aria-label="Question name">
        <input class="input time" type="number" min="1" value="${time}" placeholder="Time (min)" aria-label="Time in minutes">
        <input class="input marks" type="number" min="0" step="0.5" value="${marks}" placeholder="Expected marks" aria-label="Expected marks">
        <button class="btn icon remove" type="button" aria-label="Remove question">Remove</button>
    `;
    row.querySelector(".remove").addEventListener("click", () => {
        row.remove();
    });
    questionsBox.appendChild(row);
}

function collectQuestions() {
    return [...questionsBox.querySelectorAll(".question-row")].map(row => ({
        name: row.querySelector(".name").value.trim(),
        time: row.querySelector(".time").value,
        marks: row.querySelector(".marks").value
    }));
}

function renderResult(data) {
    document.getElementById("maxMarks").textContent = data.maximum_expected_marks;
    document.getElementById("timeUsed").textContent = `${data.time_used} min`;
    document.getElementById("unusedTime").textContent = `${data.unused_time} min`;

    const percentage = data.total_time ? Math.round((data.time_used / data.total_time) * 100) : 0;
    document.getElementById("progressText").textContent = `${percentage}%`;
    document.getElementById("progressBar").style.width = `${percentage}%`;

    const selectedBox = document.getElementById("selectedQuestions");
    selectedBox.innerHTML = "";

    if (!data.selected_questions.length) {
        selectedBox.innerHTML = `<div class="empty">No question fits within the available exam time.</div>`;
    } else {
        data.selected_questions.forEach(q => {
            const item = document.createElement("div");
            item.className = "selected-item";
            item.innerHTML = `
                <div><strong>${escapeHtml(q.name)}</strong><span>${q.time} minutes</span></div>
                <div><strong>${q.marks} marks</strong><span>Expected score</span></div>
            `;
            selectedBox.appendChild(item);
        });
    }

    resultCard.classList.remove("hidden");
    resultCard.scrollIntoView({ behavior: "smooth", block: "start" });
}

function escapeHtml(text) {
    return String(text)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

async function optimize() {
    errorBox.textContent = "";
    resultCard.classList.add("hidden");

    const payload = {
        total_time: document.getElementById("totalTime").value,
        questions: collectQuestions()
    };

    optimizeBtn.disabled = true;
    optimizeBtn.textContent = "Optimizing...";

    try {
        const response = await fetch("/api/optimize", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Unable to optimize questions.");
        renderResult(data);
    } catch (error) {
        errorBox.textContent = error.message;
    } finally {
        optimizeBtn.disabled = false;
        optimizeBtn.textContent = "Optimize Question Selection";
    }
}

addQuestionBtn.addEventListener("click", () => addQuestion());
optimizeBtn.addEventListener("click", optimize);

// Ready-to-demo sample data.
addQuestion("Q1", 20, 10);
addQuestion("Q2", 15, 8);
addQuestion("Q3", 30, 14);
addQuestion("Q4", 10, 5);
addQuestion("Q5", 25, 12);
