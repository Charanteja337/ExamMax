from flask import Flask, jsonify, render_template, request

from algorithm import Question, optimize_questions

app = Flask(__name__)


@app.get("/")
def home():
    return render_template("index.html")


@app.post("/api/optimize")
def optimize():
    data = request.get_json(silent=True) or {}

    try:
        total_time = int(data.get("total_time", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "Total exam time must be a whole number."}), 400

    if total_time <= 0:
        return jsonify({"error": "Total exam time must be greater than 0 minutes."}), 400

    raw_questions = data.get("questions", [])
    if not isinstance(raw_questions, list) or not raw_questions:
        return jsonify({"error": "Add at least one question."}), 400

    questions = []
    for index, item in enumerate(raw_questions, start=1):
        try:
            name = str(item.get("name", "")).strip() or f"Q{index}"
            time = int(item.get("time", 0))
            marks = float(item.get("marks", 0))
        except (TypeError, ValueError, AttributeError):
            return jsonify({"error": f"Invalid values in question {index}."}), 400

        if time <= 0:
            return jsonify({"error": f"Time for {name} must be greater than 0."}), 400
        if marks < 0:
            return jsonify({"error": f"Expected marks for {name} cannot be negative."}), 400

        questions.append(Question(name=name, time=time, marks=marks))

    result = optimize_questions(questions, total_time)
    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True)
