"""Core Dynamic Programming algorithm for ExamMax.

Exam question selection is modeled as a 0/1 Knapsack problem:
- capacity -> total exam time (minutes)
- weight   -> estimated time for a question
- value    -> expected marks
"""

from dataclasses import dataclass, asdict
from typing import Iterable


@dataclass(frozen=True)
class Question:
    name: str
    time: int
    marks: float


def optimize_questions(questions: Iterable[Question], total_time: int) -> dict:
    """Return an optimal set of questions within ``total_time``.

    Uses classic 0/1 Knapsack dynamic programming with reconstruction.

    Time complexity: O(N * T)
    Space complexity: O(N * T)
    where N is number of questions and T is total_time.
    """
    questions = list(questions)

    if total_time < 0:
        raise ValueError("Total time cannot be negative.")

    n = len(questions)
    dp = [[0.0] * (total_time + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        q = questions[i - 1]
        for t in range(total_time + 1):
            without_q = dp[i - 1][t]
            with_q = float("-inf")
            if q.time <= t:
                with_q = dp[i - 1][t - q.time] + q.marks
            dp[i][t] = max(without_q, with_q)

    # Reconstruct selected questions.
    selected = []
    t = total_time
    for i in range(n, 0, -1):
        # Small tolerance prevents float comparison noise.
        if abs(dp[i][t] - dp[i - 1][t]) > 1e-9:
            q = questions[i - 1]
            selected.append(q)
            t -= q.time

    selected.reverse()
    time_used = sum(q.time for q in selected)
    max_marks = sum(q.marks for q in selected)

    return {
        "selected_questions": [asdict(q) for q in selected],
        "maximum_expected_marks": round(max_marks, 2),
        "time_used": time_used,
        "unused_time": total_time - time_used,
        "total_time": total_time,
        "questions_considered": n,
    }
