import unittest

from algorithm import Question, optimize_questions


class ExamMaxAlgorithmTests(unittest.TestCase):
    def test_normal_case(self):
        questions = [
            Question("Q1", 20, 10),
            Question("Q2", 15, 8),
            Question("Q3", 30, 14),
            Question("Q4", 10, 5),
            Question("Q5", 25, 12),
        ]
        result = optimize_questions(questions, 60)
        self.assertEqual(result["maximum_expected_marks"], 30)
        self.assertEqual(result["time_used"], 60)
        self.assertEqual([q["name"] for q in result["selected_questions"]], ["Q1", "Q2", "Q5"])

    def test_no_question_fits(self):
        result = optimize_questions([Question("Q1", 10, 5)], 5)
        self.assertEqual(result["maximum_expected_marks"], 0)
        self.assertEqual(result["selected_questions"], [])

    def test_exact_fit(self):
        questions = [Question("Q1", 10, 5), Question("Q2", 20, 10)]
        result = optimize_questions(questions, 30)
        self.assertEqual(result["maximum_expected_marks"], 15)
        self.assertEqual(result["time_used"], 30)

    def test_single_question(self):
        result = optimize_questions([Question("Q1", 10, 5)], 10)
        self.assertEqual(result["maximum_expected_marks"], 5)
        self.assertEqual(result["time_used"], 10)


if __name__ == "__main__":
    unittest.main()
