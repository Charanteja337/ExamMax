# ExamMax 🎓

**Smart Exam Question Selection using Dynamic Programming**

ExamMax is a DAA hackathon project that helps select which exam questions to attempt when examination time is limited. It models the decision as a **0/1 Knapsack problem** and maximizes expected marks without exceeding the available time.

## Features

- Add or remove exam questions dynamically.
- Enter estimated time and expected marks for every question.
- Uses Dynamic Programming to find an optimal selection.
- Shows selected questions, maximum expected marks, time used, unused time, and time-utilization percentage.
- Includes API validation and automated algorithm tests.
- Responsive interface suitable for a live hackathon demo.

## Algorithm

For each question:
- **Weight** = estimated answer time.
- **Value** = expected marks.
- **Capacity** = available exam time.

The project uses 0/1 Knapsack Dynamic Programming because each exam question can be selected at most once.

### Complexity

- Time Complexity: `O(N × T)`
- Space Complexity: `O(N × T)` for reconstruction of selected questions.

Where `N` is the number of questions and `T` is total available time in minutes.

## Project Structure

```text
ExamMax/
├── app.py
├── algorithm.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── script.js
├── tests/
│   └── test_algorithm.py
└── docs/
    └── algorithm.md
```

## Run Locally

### 1. Clone or download the project

```bash
git clone <your-repository-url>
cd ExamMax
```

### 2. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install requirements

```bash
pip install -r requirements.txt
```

### 4. Start ExamMax

```bash
python app.py
```

Open the local address shown by Flask, normally:

```text
http://127.0.0.1:5000
```

## Run Tests

From the project root:

```bash
python -m unittest discover -s tests
```

## Sample Demo

Available time: **60 minutes**

| Question | Time | Expected Marks |
|---|---:|---:|
| Q1 | 20 min | 10 |
| Q2 | 15 min | 8 |
| Q3 | 30 min | 14 |
| Q4 | 10 min | 5 |
| Q5 | 25 min | 12 |

One optimal result is:

- Q1 + Q2 + Q5
- Time used: **60 minutes**
- Expected marks: **30**

## Hackathon Viva Points

1. The problem is an optimization problem.
2. It maps directly to 0/1 Knapsack.
3. Dynamic Programming avoids recomputing overlapping subproblems.
4. Each question is selected at most once.
5. Time complexity is `O(N × T)`.
6. This implementation keeps a 2D DP table so the chosen questions can be reconstructed.
7. The web interface makes the DAA algorithm easy to demonstrate interactively.

## Team Role Suggestion

- Member 1: Problem Analysis + Algorithm
- Member 2: Implementation + Integration
- Member 3: Testing + Debugging + Optimization
- Member 4: GitHub + Documentation + Presentation

## License

This project is intended for educational and hackathon use.
